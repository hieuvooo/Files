make sure tsschecker_windows.exe is in the same directory as cacert.pem
otherwise you will get CURL error
